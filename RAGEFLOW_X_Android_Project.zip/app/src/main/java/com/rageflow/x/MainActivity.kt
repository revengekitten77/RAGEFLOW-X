package com.rageflow.x

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

class MainActivity : ComponentActivity() {
    private var recorder: MediaRecorder? = null
    private var output: File? = null
    private val micPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        setContent { RageFlowApp() }
    }

    fun toggleRecording(recording: Boolean) {
        if (recording) {
            output = File(cacheDir, "rageflow_${System.currentTimeMillis()}.m4a")
            recorder = MediaRecorder(this).apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setOutputFile(output!!.absolutePath)
                prepare(); start()
            }
        } else {
            recorder?.runCatching { stop(); release() }
            recorder = null
        }
    }

    @Composable fun RageFlowApp() {
        var tab by remember { mutableStateOf(0) }
        var recording by remember { mutableStateOf(false) }
        var drill by remember { mutableStateOf("LOW START — HARD EMPHASIS — SHORT PAUSE — CLEAN EXIT.") }
        var bpm by remember { mutableIntStateOf(92) }
        val drills = listOf(
            "LOW START — HARD EMPHASIS — SHORT PAUSE — CLEAN EXIT.",
            "BREATH IN — HIT THE FIRST WORD — STAY CONTROLLED — RESET.",
            "SHARP CONSONANTS — DARK RESONANCE — CLEAN BREATH.",
            "QUIET BAR — HARD EMPHASIS — SILENCE — NEXT BAR."
        )
        MaterialTheme(colorScheme = darkColorScheme()) {
            Surface(Modifier.fillMaxSize(), color = Color(0xFF050505)) {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
                    Text("RAGEFLOW X", fontSize=30.sp, color=Color.White)
                    Text("VOCAL LAB / ANDROID", fontSize=11.sp, color=Color.Gray)
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                        listOf("LAB","DRILLS","WRITE","GUIDE").forEachIndexed { i, t ->
                            Button(onClick={tab=i}) { Text(t) }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    when(tab) {
                        0 -> {
                            Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF111113)), shape=RoundedCornerShape(22.dp)) {
                                Column(Modifier.padding(18.dp)) {
                                    Text("LIVE DELIVERY SCORE", color=Color.Gray, fontSize=11.sp)
                                    Text(if(recording) "LIVE" else "--", fontSize=58.sp)
                                    Text("Build aggression through breath, resonance, articulation and rhythm — never by forcing your throat.", color=Color.Gray)
                                    Spacer(Modifier.height(12.dp))
                                    Button(onClick={
                                        recording=!recording
                                        toggleRecording(recording)
                                    }) { Text(if(recording) "■ STOP TAKE" else "● START TAKE") }
                                }
                            }
                            Spacer(Modifier.height(12.dp))
                            StatCard("ENERGY", if(recording) "LIVE" else "0%")
                            StatCard("CONTROL", if(recording) "LIVE" else "0%")
                        }
                        1 -> {
                            Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF111113)), shape=RoundedCornerShape(22.dp)) {
                                Column(Modifier.padding(18.dp)) {
                                    Text("🔥 RAGE DRILL", color=Color.Gray)
                                    Spacer(Modifier.height(8.dp))
                                    Text(drill, fontSize=22.sp)
                                    Spacer(Modifier.height(12.dp))
                                    Button(onClick={drill=drills.random()}) { Text("NEW DRILL") }
                                    Spacer(Modifier.height(18.dp))
                                    Text("$bpm BPM", fontSize=42.sp)
                                    Row(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                                        Button(onClick={bpm=(bpm-4).coerceAtLeast(60)}) { Text("-4") }
                                        Button(onClick={bpm=(bpm+4).coerceAtMost(160)}) { Text("+4") }
                                    }
                                }
                            }
                        }
                        2 -> {
                            var text by remember { mutableStateOf("") }
                            Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF111113)), shape=RoundedCornerShape(22.dp)) {
                                Column(Modifier.padding(18.dp)) {
                                    Text("✍️ VERSE LAB", fontSize=20.sp)
                                    Text("Write 4–8 bars. Use CAPS for emphasis.", color=Color.Gray)
                                    Spacer(Modifier.height(10.dp))
                                    OutlinedTextField(text, {text=it}, Modifier.fillMaxWidth().height(180.dp))
                                    Text("${text.trim().split(Regex("\\s+")).filter{it.isNotEmpty()}.size} words", color=Color.Gray)
                                }
                            }
                        }
                        3 -> {
                            Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF111113)), shape=RoundedCornerShape(22.dp)) {
                                Column(Modifier.padding(18.dp)) {
                                    Text("🧠 DEEP VOICE COACH", fontSize=20.sp)
                                    listOf("Relax your jaw and neck.", "Use steady breath support.", "Let resonance make the tone fuller.", "Keep consonants sharp.", "Stop if you feel pain or persistent hoarseness.").forEach { Text("• $it", Modifier.padding(vertical=7.dp), color=Color.LightGray) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    @Composable fun StatCard(label:String, value:String) {
        Card(Modifier.fillMaxWidth().padding(vertical=5.dp), colors=CardDefaults.cardColors(containerColor=Color(0xFF101012))) {
            Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
                Text(label, color=Color.Gray); Text(value, fontSize=24.sp)
            }
        }
    }
}
